angular.module('home.services', [])
  .factory('HomeFty', function($http,$q) {
    return null;

  });
