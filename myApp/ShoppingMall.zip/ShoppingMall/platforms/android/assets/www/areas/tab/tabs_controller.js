// tabs功能controller
angular.module('tabs.controller', [])
  .controller('TabsCtrl', function($scope,GlobalVariable) {

  })
