angular.module('guidePage.services', [])
  .factory('GuidePageFty', function($http,$q) {
    return {
      get:function(){},
      postdata:function(){},
      deletedata:function(){}
    };

  });
