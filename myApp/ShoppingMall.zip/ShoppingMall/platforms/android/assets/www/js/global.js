// 全局变量文件
angular.module('global', [])
  .constant("GlobalVariable",{
    'SERVER_PATH':'192.168.1.1:8080/',
    'VERSION':"1.2.1"
  })
