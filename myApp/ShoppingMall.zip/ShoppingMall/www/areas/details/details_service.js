// 商品详细页面
angular.module('details.service', [])
  .factory('DetailsFty', function ($http, $q) {
    return {

    }
  });
