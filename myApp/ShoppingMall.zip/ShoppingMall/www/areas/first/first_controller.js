// 第一个页面的控制器
angular.module('first.controller', [])
  .controller('FirstCtrl', function($scope) {



  })
